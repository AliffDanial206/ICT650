<?php


$link = mysqli_connect("localhost",'root','','hazard');



 ?>
